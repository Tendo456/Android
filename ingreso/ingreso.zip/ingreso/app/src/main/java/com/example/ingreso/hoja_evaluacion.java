package com.example.ingreso;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class hoja_evaluacion extends AppCompatActivity {

    RadioButton rbP1_1,rbP1_2,rbP1_3,rbP2_1,rbP2_2,rbP2_3,rbP3_1,rbP3_2,rbP3_3;
    EditText Coment1,Coment2,Coment3;
    Button btEnviar,btCancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hoja_evaluacion);

        rbP1_1 = findViewById(R.id.rbP1_1);
        rbP1_2 = findViewById(R.id.rbP1_2);
        rbP1_3 = findViewById(R.id.rbP1_3);
        rbP2_1 = findViewById(R.id.rbP2_1);
        rbP2_2 = findViewById(R.id.rbP2_2);
        rbP2_3 = findViewById(R.id.rbP2_3);
        rbP3_1 = findViewById(R.id.rbP3_1);
        rbP3_2 = findViewById(R.id.rbP3_2);
        rbP3_3 = findViewById(R.id.rbP3_3);
        Coment1 = findViewById(R.id.Coment1);
        Coment2 = findViewById(R.id.Coment2);
        Coment3 = findViewById(R.id.Coment3);
        btEnviar = findViewById(R.id.btEnviar);
        btCancelar = findViewById(R.id.btCancelar);

    }
}